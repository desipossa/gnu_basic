</div>
                </article>
                <aside id="aside">
<?php
    include G5_THEME_PATH.'/doc/nav.php';
?>
                </aside>
            </div>
        </div>