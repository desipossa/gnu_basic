<ul>
    <li><a href="<?php echo G5_THEME_URL ?>/doc/m011.php">회사소개</a></li>
    <li><a href="<?php echo G5_THEME_URL ?>/doc/m012.php">오시는길</a></li>
    <li><a href="/bbs/board.php?bo_table=qa">문의게시판</a></li>
    <li><a href="/bbs/board.php?bo_table=notice">알려드립니다.</a></li>
    <li><a href="/bbs/board.php?bo_table=gallery">사진갤러리</a></li>
</ul>