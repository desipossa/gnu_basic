<div id="subPage">
            <div class="sub_bar">
                <div class="inner">
                    <span><?= $title ?> / <?= $company ?></span>
                </div>
            </div>
            <div class="inner">
                <article id="article">
                    <h2><?= $title ?> / <span><?= $company ?></span></h2>
                    <div class="content">