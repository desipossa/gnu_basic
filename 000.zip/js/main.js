$(function () {
    $('.mainSlide').slick({
        arrows: false,
        dots: true,
    })
})